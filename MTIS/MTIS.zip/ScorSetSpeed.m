function confirmation=ScorSetSpeed(PrcSpd)
% FUNCTION confirmation=ScorSetSpeed(PrcSpd)
% set speed in percent of max speed, must be integer beween 0 and 100
% confirmation = 1 success, 0 failed
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
confirmation=calllib('RobotDll','RSetSpeed',round(PrcSpd));

