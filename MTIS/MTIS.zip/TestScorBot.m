%% Test Script for new ScorBots
% Start up checklist
% 1. E-stops reset on Teach Pendant and MiniTower
% 2. Teach Pendant in Holster
% 3. Teach Pendant in Auto Mode
addpath('N:\New Scorbot\EspoNewScorbot')
ScorInit % Initialize connection
ScorHome  % Homing, takes a few minutes
XYZPR = ScorGetXYZPR % should say  16.9030  0 50.4328  -63.5480  0
ScorSetGripper(-1);  % Open
disp('Did the gripper open?')
ScorSetGripper(0);  % Close
disp('Did the gripper close?')
ScorCartMove([5 0 0 0 0]); % Move 5 cms forward
disp('Did the gripper move 5 centimeters away from base?')
ScorCartMove([-5 0 0 0 0]); % move 5 cms backward
disp('Did the gripper move back to the original position?')