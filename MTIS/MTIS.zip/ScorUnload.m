function ScorUnload
% unloads the DLL libraries.   You should not need to do this 
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
unloadlibrary('RobotDll');