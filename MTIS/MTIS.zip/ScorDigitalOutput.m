function ScorDigitalOutput(D,OnOff)
%Outputs a value to digital output 
%value is the bit to be activated/deactivated
%if OnOff=0 the bit is off
%if OnOff=1 the bit is on
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
if(OnOff==0) calllib('RobotDll','RDigOff',D);
else if(OnOff==1) calllib('RobotDll','RDigOn',D);
    end
end