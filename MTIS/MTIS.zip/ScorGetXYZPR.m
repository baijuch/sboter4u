function XYZPR=ScorGetXYZPR
% XYZPR=ScorGetCart
% returns X,Y,Z (cms) and pitch and roll (degs)
% as a 5 X 1 row vector;
% If it fails, returns nan  (check with isnan) 
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
F = 0; X = 0.0; Y = 0.0; Z = 0.0; P = 0.0; R = 0.0;
try
[F,X,Y,Z,P,R]=calllib('RobotDll','RGetXYZPR',X,Y,Z,P,R);
XYZPR(1)=X/10000;
XYZPR(2)=Y/10000;
XYZPR(3)=Z/10000;
XYZPR(4)=P/1000;
XYZPR(5)=R/1000;
catch
    XYZPR = nans(1,5);
end