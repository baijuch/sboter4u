function []= ScorRequestPendantMode(desiredMode)
% FUNCTION []= REQUESTPENDANTMODE(desiredMode);
% Where desiredMode is 'auto' ( by default )
% or 'teach' (include single quotes, case sensitive)
% A utility function that checks the mode of the teach pendant
% and waits (possibly for ever) until the user 
% switches it to the desired mode.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010


if strcmp(desiredMode, 'teach')
    modeFlag = 1; 
elseif strcmp(desiredMode, 'auto')
    modeFlag = 0;
else
    disp('Warning: RequestPendantMode defaulting to Auto as desired mode!')
    desiredMode='auto';
    modeFlag = 0;
end


Mode= calllib('RobotDll','RIsTeach');
while(Mode~=modeFlag)
    beep; beep;
    disp('Error: Please Switch Pendant Mode to:  ');
    fprintf(desiredMode);
    fprintf('\r\n');
    
    pause(1)
    Mode=calllib('RobotDll','RIsTeach');
    if Mode==modeFlag
        disp('Pendant now in proper mode! Proceeding...')
    end
end
