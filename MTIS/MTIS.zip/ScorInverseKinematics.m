function [theta]=ScorInverseKinematics(x,y,z)
% assumes gripper pitched straight down (-pi/2).
% THETA=ScorInverseKinnematics(X,Y,Z) converts Cartesian end-effector 
% positions to joint angles.
%
% - X,Y, and Z are scalar variables in meters.
% - THETA is a 3x1 vector in radians.
%
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
% 
zw=z+0.145;
a=sqrt(x^2+y^2)-.016;
b=zw-0.349;
d=sqrt(a^2+b^2);
cosgam=(0.221^2+0.221^2-d^2)/(2*0.221*0.221);
singam=-sqrt(1-cosgam^2);
gamma=atan2(singam,cosgam);
theta3=pi-gamma;
beta=atan2(0.221*sin(theta3),0.221+0.221*cos(theta3));
alpha=atan2(b,a);
theta2=alpha-beta;
theta1=atan2(y,x);
theta=[theta1;theta2;theta3];