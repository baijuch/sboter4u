% confirmation = ScorDeltaJtMove(deltaBSEPR)
% incremental (delta) change in joints angles 
% deltaBSEPR - 1x5 vector of five (Base, Shoulder, Elbow, Pitch, Roll) 
% joint increments in degrees to add to current 
% robot position to define desired final move position joint angles
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
function confirmation = ScorDeltaJtMove(deltaBSEPR)
deltaBSEPR(2) =-deltaBSEPR(2);  % Their angles do not match teach pendant or DH  
deltaBSEPR(3) =-deltaBSEPR(3);
deltaBSEPR(4) =-deltaBSEPR(4);
ScorRequestPendantMode('auto')
xc=ScorGetXYZPR;            %current position vector [x,y,z,pitch,roll]
thc=ScorX2Deg(xc);          %compute current joint angle vector
thf=thc+deltaBSEPR;                %final move position joint angle vector
xf=ScorDeg2X(thf);          %final move position vector [x,y,z,pitch,roll]
confirmation = ScorAddToVec(1000, xf);
if confirmation
    confirmation = ScorMoveToPt(1000, 'J');
end


if(confirmation==1)
	ScorBlockUntilMotionComplete(xf);
end
