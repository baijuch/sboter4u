function ScorSafeShutDown
% ScorSafeShutDown Run this command before exiting Matlab
% Since the scorbot loses power as soon as matlab is exited 
% you should get it back into a neutral position.

Home = [16.9030         0   50.4328  -63.5480         0];
ScorCartMove(Home);
ScorControlEnable(0);