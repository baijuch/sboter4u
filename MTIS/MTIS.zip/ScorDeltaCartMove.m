function confirmation=ScorDeltaCartMove(deltaXYZPR)
% confirmation=ScorDeltaCartMove(dXYZPR)
% Commands an incremental (delta) motion in XYZPR 
% format.  deltaXYZPR is a 1 X 5 vector where 
% X,Y,Z in cm and P,R in deg
% returns 1 if point succesful. Fails (confirmation =0)
% if the point results outside of workspace
% Note:  May miss rapid sequences of commands when in Teach Mode.   
% Auto mode ensures proper execution.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

ScorRequestPendantMode('auto')
XYZPRold = ScorGetXYZPR;
confirmation = ScorAddToVec(1000, XYZPRold + deltaXYZPR);
if confirmation
    confirmation = ScorMoveToPt(1000, 'L');
end

if(confirmation==1)
	ScorBlockUntilMotionComplete(XYZPRold + deltaXYZPR);
end
  
