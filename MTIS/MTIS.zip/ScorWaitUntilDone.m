function ScorWaitUntilDone()
% OLD....NO LONGER SUPPORTED!
% SEE ScorBlockUntilMotionComplete instead
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
    BSEPRold = ScorGetBSEPR;
    GripOld = ScorGetGripper;
    busy=1;
    while busy ==1;
        Ready = calllib('RobotDll','RIsMotionDone');
        BSEPR = ScorGetBSEPR;
        EndMovement = norm(BSEPR-BSEPRold);    
        Gripper = ScorGetGripper;
        GripperMovement = abs(Gripper - GripOld);
        fprintf('R: %d,  E: %f, G: %f \n',[Ready, EndMovement, GripperMovement])
        if Ready==1 && EndMovement<1.7453e-004 &&  GripperMovement<.1
            busy =0;
        else
            GripOld = Gripper;
            BSEPRold = BSEPR;
        end
    end