function BSEPR=ScorGetJt
% FUNCTION BSEPR=ScorGetJt
% returns Base,Shoulder,Elbow,Pitch,Roll
% signed angles in Degrees
% 
% Note that + direction for pitch and elbow is opposite from teach pendant
% labeling!  This code fixes this.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

F = 0; B = 0.0; S = 0.0; E = 0.0; P = 0.0; R = 0.0; 
%Notes: Provided USBC.DLL does not seem to 
% accept these values in When in Teach routine? Not sure
try
    [F,B,S,E,P,R]=calllib('RobotDll','RGetBSEPR',B,S,E,P,R);
catch
    disp('ScorGetJt Failed: Teach Pendant must be in Auto Mode') 
end
BSEPR=[B/1000 -S/1000 -E/1000 -P/1000 R/1000];