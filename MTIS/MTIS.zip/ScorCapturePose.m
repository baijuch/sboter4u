function [XYZPR, confirmation]=ScorCapturePose(Pt)
% FUNCTION [XYZPR, confirmation]=ScorCapturePose(Pt)
% Record current pose as point # Pt (1 to 999) in the controller 
% and returns the pose to the MATLAB workspace as XYZPR, a 1x5 vector.
% XYZ in cms, and Pitch Roll in deg 
% confirmation is a zero for a point that is outside the allowed
% workspace or outside the range 1 to 999, 
% confirmation is  1 if succesful
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
ScorRequestPendantMode('teach');
XYZPR=ScorGetXYZPR;
F=ScorAddToVec(Pt,XYZPR);
if F >0
    confirmation = 1;
else
    confirmation = 0;
end
disp('We suggest you switch the teach pendant back to AutoMode before executing any movements.') 