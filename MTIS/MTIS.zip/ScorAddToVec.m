function confirmation=ScorAddToVec(Pt,XYZPR)
%  confirmation=ScorAddToVec(Pt,XYZPR)
% Adds a new absolute pose XYZPR (cm / deg)
% Pt is the index in the vector of poses stored on robot 1-999
% returns 1 if point was added. Points will not be added (returns 0)
% if the point results outside of workspace
% Note: Joint angles cannot be added by this method (USBC.dll problem)
%   By: Wick & Esposito & Knowles, US Naval Academy, 2010
FVal=0;
for i=1:3
    V1(i)=fix(XYZPR(i)*10000);
end
for i=4:5
    V1(i)=fix(XYZPR(i)*1000) ;
end;
%disp('XYZ Absolute');
[FVal,NVal]=calllib('RobotDll','RAddToVecXYZPR','USNA',Pt,0,V1(1),V1(2),V1(3),V1(4),V1(5));
confirmation=(FVal>0);