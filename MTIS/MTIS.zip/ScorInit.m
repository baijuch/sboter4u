function ScorInit
% FUNCTION SCORINIT 
% No inputs or outputs
% loads special RobotDll file and Initializes Robot. 
% Light should turn green on control unit and beep.
% Control is set "on' for all axes
% It is recommended you  then home the robot with ScorHome
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

% Note Old version required it to be in auto mode.  Why?
warning off
disp('Loading Dll Files');
if  ~libisloaded('RobotDll')|| ~libisloaded('RobotDll.h')
    try
        loadlibrary('N:\ES450\Code\RobotDll','N:\ES450\Code\RobotDll.h');
    catch
        try
            loadlibrary('M:\ES450\Code\RobotDll','M:\ES450\Code\RobotDll.h');
        catch
            try
            loadlibrary('RobotDll','RobotDll.h');
            catch
                beep
                disp('ERROR: DID NOT FIND ROBOTDLL !!!')
            end
        end
    end
end
disp('Initializing USB interface ...');
calllib('RobotDll','RInitialize');
pause(2);
while (calllib('RobotDll','RIsInitDone')==0)
    % Blocking until initialized
	pause(.1);
end;
disp('POWER Light turned Green if successful.')
fprintf('\n')
% if(calllib('RobotDll','RIsTeach')==1)
%     disp('Pendant in Teach Mode - Please Switch to Auto!');
%     while(calllib('RobotDll','RIsTeach')==1);
%         disp('Pendant in Teach Mode - Please Switch to Auto!')
%         pause(.5)
%     end;
% end;

%disp('Turning Motor Control On');
%calllib('RobotDll','RControl',int8('A'),1);
%pause(1)
calllib('RobotDll','RDefineVector','USNA',1000);
pause(1)
disp('Ready!')
fprintf('\n')
disp('Turn teach pendant to AUTO')
disp('and home the robot with ScorHome.')

warning on
