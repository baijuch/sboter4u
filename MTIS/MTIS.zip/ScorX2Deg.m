% FUNCTION BSEPR=ScorX2Deg(XYZPR)
% theta=ScorX2Deg(x) computes the D-H joint angle vector, theta, 
% as a function of the end-effector position vector, x
% (Note: it assumes an "elbow down" arm configuration)
% x - 1x5 vector of x, y, z in cm; pitch, roll in degrees
% theta - 1x5 vector of five D-H joint angles in degrees
%
% Prepared by Dr. Ken Knowles March 2010; Modified August 2010
% See also ScorDeg2X
function theta=ScorX2Deg(x)
d1=34.9;
a1=1.6;
a2=22.1;
a3=22.1;
d5=14.5125;
pitch=pi*x(4)/180;%in radians
theta(1)=(180/pi)*atan2(x(2),x(1));%in degrees
theta(5)=x(5);%in degrees
r=sqrt(x(1)^2+x(2)^2)-a1-d5*cos(pitch);
h=x(3)-d1-d5*sin(pitch);
gamma=atan2(h,r);%in radians
b=sqrt(h^2+r^2);
alpha=atan2(sqrt(4*a2^2-b^2),b);%in radians
theta(2)=-(180/pi)*(alpha+gamma);%in degrees
theta(3)=(360/pi)*alpha;%in degrees
theta(4)=-x(4)-theta(2)-theta(3);%in degrees
theta=theta(:)';