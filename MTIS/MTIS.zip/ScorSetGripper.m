function confirmation=ScorSetGripper(cm)
% FUNCTION confirmation=ScorSetGripper(cm)
% set open width of gripper cm in centimeters
% open gripper fully if cm= -1, fully closed if cm=0, 
% Full open is 7 cm
% does not account for width of pads (approx 0.15cm)
% so pads just touch at ScorSetGripper(.3)
% Note:  May miss rapid sequences of commands when in Teach Mode.   
% ex: ScorSetGripper(-1); ScorSetGripper(0); ScorSetGripper(-1); 
% Only Auto mode guarantees proper execution
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

ScorRequestPendantMode('auto');

if(cm==0)
    confirmation=calllib('RobotDll','RGripClose');
elseif(cm== -1)
    confirmation=calllib('RobotDll','RGripOpen');
else
    % convert cm to millimeters
    confirmation=calllib('RobotDll','RGripMetric',round(10*cm));
end

if calllib('RobotDll','RIsMotionDone')==-1
    pause(1)
else
    while( calllib('RobotDll','RIsMotionDone')==0)
        % Blocking command line until finished....Does not work in Teach
        % mode! 
        %disp('.')
    end
end