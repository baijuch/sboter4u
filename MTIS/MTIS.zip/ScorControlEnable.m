function confirmation=ScorControlEnable(OnOff)
% confirmation=ScorControlEnable(OnOff)
% Can help recover after a crash.  Also can be done with Teach Pendant
% CONTROL ON/OFF <ENTER>
%if OnOff = 0 all joints are turned off
%if OnOff = 1 all joints are turned on
%returns 1 if successful
%By: Wick & Esposito & Knowles, US Naval Academy, 2010
confirmation=calllib('RobotDll','RControl',int8('A'),OnOff);