% FUNCTION confirmation =ScorJtMoveWristLevel(BSE)
% moves to a position defined by 
% 1x3 vector of joint angles in radians
% [Base, Shoulder, Elbow]
% Keeps global pitch and roll = 0 (level wrist)
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
function confirmation = ScorJtMoveWristLevel(BSE)
BSE = 180/pi* BSE; %degs
% keep wrist level
BSE(end+1) = -( BSE(2) + BSE(3) );
BSE(end+1) = 0;
confirmation =ScorJtMove(BSE);
