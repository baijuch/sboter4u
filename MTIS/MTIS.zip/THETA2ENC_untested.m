% THETA2ENC
% Q = THETA2ENC(THETA) converts relative DH joint angles to 
% Scorbot encoder counts.
% - Q is a 5x1 vector in encoder counts.
% - THETA is a 5x1 vector in radians
% 
% See also ENC2THETA
function q=theta2enc(theta)
thetad=(180/pi)*theta;%convert to degrees
k=[141.8888, -113.5111, 113.5111, 55.8 -55.8];
q(1)=k(1)*thetad(1);
q(2)=k(2)*(thetad(2)-120.3);
q(3)=k(3)*(thetad(2)+thetad(3)-25.3);
q(4)=(k(4)*(thetad(2)+thetad(3)+thetad(4)-26.5)+k(5)*thetad(5))/2;
q(5)=k(5)*thetad(5)-q(4);
q=round(q(:));%make integers