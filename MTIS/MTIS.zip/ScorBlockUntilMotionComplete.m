function  ScorBlockUntilMotionComplete(XYZPR)
% This is a utility function that  blocks new commands 
% until robot finshes iexecuting current command.
% only works in Auto mode.  Only call this function after 
% you check via "confirmation" that command has NOT failed.
%  Esposito 10/1/2011
% DEV NOTE:   tolerances can be changed to suit taste.  Is pause really
% needed?


% you can tweak these if you like.
% Too small and there is  adanger robot will never complete motion.
DistTol = 1.0;  %  10 * Linear resolution in cm 
AngleTol = 5.0;  % 10 * angular resolution in degrees
PauseTime = 0.01;  % in seconds, is this really needed?
CurrentXYZPR = ScorgetXYZPR;        
HowFarToGo = norm( CurrentXYZPR(1:3)-XYZPR(1:3) );
PitchToGo =  abs( CurrentXYZPR(4)-XYZPR(4) );
RollToGo =  abs( CurrentXYZPR(5)-XYZPR(5) );

while((calllib('RobotDll','RIsMotionDone'))==0)  || HowFarToGo> DistTol  ||  PitchToGo>AngleTol || RollToGo>AngleTol 
	CurrentXYZPR = ScorgetXYZPR;        
	HowFarToGo = norm( CurrentXYZPR(1:3)-XYZPR(1:3) );
   	PitchToGo =  abs( CurrentXYZPR(4)-XYZPR(4) );
    RollToGo =  abs( CurrentXYZPR(5)-XYZPR(5) );
    pause(PauseTime);
end