function confirmation=ScorSetMovetime(t)
% confirmation=ScorSetMovetime(t)
% set time to move (seconds), effectively sets speed for movement.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
confirmation=calllib('RobotDll','RSetTime',1000*t);