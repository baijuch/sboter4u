function cm=ScorGetGripper
% FUNCTION cm=ScorGetGripper
% returns Jaw position in CM
% 0cm is fully closed, 
% full open about 7cm
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
cm=calllib('RobotDll','RGetJaw');
cm=cm/10;