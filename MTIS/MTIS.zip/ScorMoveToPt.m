function confirmation=ScorMoveToPt(Pt,LorJ)
% confirmation=ScorMoveToPt(Pt,LorJ)
% move to a point stored internally on the scorbot 
% Pt = 1 to 999
% LorJ is a string: Linear 'L' or Joint 'J' 
% 'L' connects the two points with a straight line in cartesian space
% 'J' connects the points with a straight line in joint space, producing
% apparently curved trajectories
% Points can only be stored in XYZPR format
% a very low move time can cause this to fail (impossible to execute)
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

ScorRequestPendantMode('auto')

if(LorJ == 'L')
    confirmation=calllib('RobotDll','RMoveLinear','USNA',Pt);
else
    if(LorJ == 'J')
        confirmation=calllib('RobotDll','RMoveJoint','USNA',Pt);
    end
end


 if(confirmation==1)
      while((calllib('RobotDll','RIsMotionDone'))==0) % only properly blocks new commands in Auto mode
     end
 end
