% FUNCTION confirmation = ScorCartMove(XYZPR)
% ScorCartMove(XYZPR)moves to a target position defined in cartesian coordinates  
% defined by vector XYZPR
% XYZPR - 1x5 vector of x, y, z in cm; pitch, roll in degrees
% confirmation = 0 is it fails.  XYZPR outside of workspace is one common
% cause of failure.
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
% Dev Note:  Changed condition to block command execution.... 
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
function confirmation = ScorCartMove(XYZPR)

% how close do you have to be to target posiution before you accept a new command



ScorRequestPendantMode('auto');
confirmation = ScorAddToVec(1000, XYZPR);
if confirmation
    confirmation = ScorMoveToPt(1000, 'L');
end

%% Block command execution until complete

if(confirmation==1)
	ScorBlockUntilMotionComplete(XYZPR);
end

end
