function RVal=ScorCreateVector(Name,Len)
% RVal=ScorCreateVector(Name,Len)
% Creates a vector on Scorbot 
% in which you can store positions
% Name (in single quotes) is a string name 
% for the vector 16 or less chars
% Len is the number of possible points in vector < 10000
% returns 1 if successful
% Used during initialization 
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
[R,NVal]=calllib('RobotDll','RDefineVector',Name,Len);
RVal=R;
