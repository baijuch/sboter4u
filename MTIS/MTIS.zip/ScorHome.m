function ScorHome
% FUNCTION ScorHome
% No inputs or outputs
% calls 'Home' routine that homes all axes before returning
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
ScorRequestPendantMode('auto');
pause(0.2);
%ScorControlEnable(1);
disp('Homing! Please wait...')
% Note: the 65 parameter is code for Ascii letter 'A'
%pause(0.2);
HomeFail = calllib('RobotDll','RHome',65);
pause(1);


Home = [16.9030         0   50.4328  -63.5480         0];
XYZPR = ScorGetXYZPR();
if norm(Home(1:3) - XYZPR(1:3))>5
    disp('Homing Failed.   Try Again?');
else
    disp('Finished homing.')
end

ScorControlEnable(1);