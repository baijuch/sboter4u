% FUNCTION cnts=ScorDeg2Cnts(theta)
% cnts=ScorDeg2Cnts(theta) converts relative D-H joint angles 
% to SCORBOT-ER 4u encoder counts
% cts - 1x5 vector of joint motor encoder counts
% theta - 1x5 vector of relative D-H joint angles in degrees
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
% See also ScorCnts2Deg
function cnts=ScorDeg2Cnts(theta)
kb=-141.8888;
kse=-113.5111;
offs=120.27;
offe=-25.24;
kw=-27.9;
offw=63.57;
cnts(1)=kb*theta(1);
cnts(2)=kse*(offs+theta(2));
cnts(3)=kse*(offe-theta(2)-theta(3));
cnts(4)=kw*(offw-theta(2)-theta(3)-theta(4)-theta(5));
cnts(5)=kw*(theta(2)+theta(3)+theta(4)-theta(5)-offw);
cnts=cnts(:)';