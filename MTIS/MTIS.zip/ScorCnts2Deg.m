% FUNCTION BSEPR=ScorCnts2Deg(cts)
% BSEPR=ScorCnts2Deg(cts) converts SCORBOT-ER 4u encoder count vector 
% to the relative D-H joint angle vector
% cts - 1x5 vector of joint motor in encoder counts
% BSEPR - 1x5 vector of relative D-H joint angles in degrees
% [Base Shoulder Elbow Pitch Roll]
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
% See also ScorDeg2Cnts
function theta=ScorCnts2Deg(cts)
kb=-141.8888;
kse=-113.5111;
offs=120.27;
offe=-25.24;
kw=-27.9;
offw=63.57;
theta(1)=cnts(1)/kb;
theta(2)=cnts(2)/kse-offs;
theta(3)=offs+offe-(cnts(2)+cnts(3))/kse;
theta(4)=(cnts(5)-cnts(4))/(2*kw)+cnts(3)/kse+offw-offe;
theta(5)=(cnts(4)+cnts(5))/(-2*kw);
theta=theta(:)';