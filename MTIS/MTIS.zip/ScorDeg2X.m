% FUNCTION XYZPR=ScorDeg2X(BSEPR)
% XYZPR=ScorDeg2X(BSEPR) computes the end-effector position vector, XYZPR, 
% (centimeters and degrees)as a function of Denavit-Hardenburg joint angle vector, 
% BSEPR- 1x5 vector of five D-H joint angles in degrees
%
%  By: Wick & Esposito & Knowles, US Naval Academy, 2010
% See also ScorX2Deg
function x=ScorDeg2X(theta)
d1=34.9;
a1=1.6;
a2=22.1;
a3=22.1;
d5=14.5125;
x(5)=theta(5);%in degrees
x(4)=-theta(2)-theta(3)-theta(4);%in degrees
pitch=(pi/180)*x(4);%in radians
tr=(pi/180)*theta;%in radians
x(3)=d1-a2*sin(tr(2))-a3*sin(tr(2)+tr(3))+d5*sin(pitch);
r=a1+a2*cos(tr(2))+a3*cos(tr(2)+tr(3))+d5*cos(pitch);
x(2)=r*sin(tr(1));
x(1)=r*cos(tr(1));
x=x(:)';