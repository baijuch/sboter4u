% ENC2THETA
% THETA = ENC2THETA(Q) converts Scorbot encoder counts to
% relative DH joint angles. 
% - Q is a 5x1 vector in encoder counts.
% - THETA is a 5x1 vector in radians
%
% See also THETA2ENC
function theta = enc2theta(q)
k=[141.8888, -113.5111, 113.5111, 55.8 -55.8];
theta(1)=q(1)/k(1);
theta(2)=q(2)/k(2) + 120.3;
theta(3)=q(3)/k(3) + 25.3 - theta(2);
theta(4)=(q(4)-q(5))/k(4)+26.5-theta(3)-theta(2);
theta(5)=(q(4)+q(5))/k(5);
theta=(pi/180)*theta(:);%convert to radians