% FUNCTION confirmation =ScorJtMove(BSEPR)
% ScorJtMove(BSEPR) moves to a position defined by 
% 1x5 vector of five joint angles in degrees
% [Base, Shoulder, Elbow, Pitch, Roll]
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
function confirmation = ScorJtMove(BSEPR)

BSEPR(2:4) = -1*BSEPR(2:4);
ScorRequestPendantMode('auto');
xf=ScorDeg2X(BSEPR)      %final move position vector [x,y,z,pitch,roll]
confirmation = ScorAddToVec(1000, xf)
if confirmation
    confirmation = ScorMoveToPt(1000, 'J')
end

if(confirmation==1)
	ScorBlockUntilMotionComplete(xf);
end