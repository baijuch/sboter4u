% confirmation = ScorDeltaJtMoveWristLevel(deltaBSE)
% incremental (delta) change in first three joints angles 
% deltaBSEPR - 1x5 vector of five (Base, Shoulder, Elbow, Pitch, Roll) 
% joint increments in RADIANS to add to current 
% robot position to define desired final move position joint angles
% Note:  May miss rapid sequences of commands when in Teach Mode.   Auto
% mode ensures proper execution.
% By: Wick & Esposito & Knowles, US Naval Academy, 2010
function confirmation = ScorDeltaJtMoveWristLevel(deltaBSE)
deltaBSE = 180/pi* deltaBSE; %degs
deltaBSE(2) =-deltaBSE(2);  % Their angles do not match teach pendant or DH  
deltaBSE(3) =-deltaBSE(3);
deltaBSE(4) = -(deltaBSE(2)+  deltaBSE(3) ); 
deltaBSE(5) = 0; 


ScorRequestPendantMode('auto')
calllib('RobotDll','RIsMotionDone')
xc=ScorGetXYZPR;            %current position vector [x,y,z,pitch,roll]
thc=ScorX2Deg(xc);          %compute current joint angle vector
thf=thc+deltaBSE';                %final move position joint angle vector
xf=ScorDeg2X(thf);          %final move position vector [x,y,z,pitch,roll]
%keeping wrist
confirmation = ScorAddToVec(1000, xf);
if confirmation
    confirmation = ScorMoveToPt(1000, 'J');
end

if(confirmation==1)
	ScorBlockUntilMotionComplete(xf);
end