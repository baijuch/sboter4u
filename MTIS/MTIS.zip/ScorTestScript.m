%% Testing Scorbots - 
% By: Wick & Esposito & Knowles, US Naval Academy, 2010

%% Initialize
ScorInit

%% Home
ScorHome

%%  Try Gripper
ScorSetGripper(-1) % Open
ScorSetGripper(0) % Close
ScorSetGripper(1) % 1 centimeter

%% Set a position
ScorSetSpeed(100)
XYZPR=ScorGetXYZPR  % get current position



%% Now cycle through them
confirmation=ScorSetMovetime(2.5)
for i= 1: 5
    ScorDeltaCartMove([10 0 0 0 20]);
    ScorDeltaCartMove([-10 0 0 0 -20]);
end

%% 